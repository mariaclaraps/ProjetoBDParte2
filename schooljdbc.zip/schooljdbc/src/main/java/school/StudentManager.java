package school;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import conexao.*;

public class StudentManager {
    

    
    public void addStudent(Student student) {
        String sqlCommand = "INSERT INTO student (nome, email) VALUES (?, ?)";
        
        try {
        	Connection conn = Conexao.obterConexao();
            PreparedStatement stmt = conn.prepareStatement(sqlCommand);
            stmt.setString(1, student.getNome());
            stmt.setString(2, student.getEmail());
            stmt.executeUpdate();
            System.out.println("Estudante adicionado com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteStudent(int id) {
        String sqlCommand = "DELETE FROM student WHERE id = ?";

        try {
        	Connection conn = Conexao.obterConexao();
            PreparedStatement stmt = conn.prepareStatement(sqlCommand);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            int tuplasAfetadas = stmt.getUpdateCount();
            if (tuplasAfetadas > 0) {
                System.out.println("Estudante deletado com sucesso!");
            } else {
                System.out.println("Nenhum estudante foi deletado. O id não existe no banco de dados.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Student> getStudents() {
        String sqlCommand = "SELECT * FROM student";
        List<Student> Students = new ArrayList<>();

        try {
        	Connection conn = Conexao.obterConexao();
            PreparedStatement stmt= conn.prepareStatement(sqlCommand);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
            	
            	int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String email = rs.getString("email");
                System.out.println("Id: " + id + " - Name: " + nome + " - Email: " + email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return Students;
    }

    public void updateStudent(int id, String novoNome, String novoEmail) {
        String sqlCommand = "UPDATE student SET nome = ?, email = ? WHERE id = ? ";

        try {
        	Connection conn = Conexao.obterConexao();
            PreparedStatement stmt = conn.prepareStatement(sqlCommand);
            stmt.setString(1, novoNome);
            stmt.setString(2, novoEmail);
            stmt.setInt(3, id);
            stmt.executeUpdate();
            int tuplasAfetadas = stmt.executeUpdate();
            
            if(tuplasAfetadas > 0) {
            	System.out.println("Estudante atualizado com sucesso!");
            } else {
            	System.out.println("Estudante com id informado não foi encontrado!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
