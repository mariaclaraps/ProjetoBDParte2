package school;

import java.util.Scanner;

public class Student {
	private long id;
	private String nome;
	private String email;
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public static Student formStudent() {
		Scanner entrada = new Scanner (System.in);
		Student student = new Student();
		System.out.println("Digite o nome do estudante:");
		student.nome = entrada.nextLine();
		System.out.println("Digite o email do estudante:");
		student.email = entrada.nextLine();
		
		return student;
	}
	
	
}
