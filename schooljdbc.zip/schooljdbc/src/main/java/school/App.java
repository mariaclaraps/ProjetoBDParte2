package school;

import java.util.*;
public class App {
	public static void main(String[] args) {
		try(Scanner entrada = new Scanner(System.in)){
			StudentManager sm = new StudentManager();
			boolean  sair =  true;
			int escolha;
	
			do {
				System.out.println("=====================================");
				System.out.println("|| ----------- MENU -------------- ||");
				System.out.println("|| 1 - Adicionar estudante         ||");
				System.out.println("|| 2 - Listar estudantes           ||");
				System.out.println("|| 3 - Atualizar estudante         ||");
				System.out.println("|| 4 - Remover estudante           ||");
				System.out.println("|| 5 - Sair                        ||");
				System.out.println("|| ------------------------------- ||");
				System.out.println("=====================================");
				System.out.println("----- Escolha uma opção acima: ------");
				escolha = entrada.nextInt();
				switch (escolha) {
					case 1:
						Student student = Student.formStudent();
						sm.addStudent(student);
						break;
					case 2:
						sm.getStudents();
						break;
					case 3:
						int id;
						String newName;
						String newEmail;
						System.out.println("Digite o id do estudante que você deseja atualizar:");
						id = entrada.nextInt();
						entrada.nextLine();
						System.out.println("Digite o novo nome:");
						newName = entrada.nextLine();
						System.out.println("Digite o novo email:");
						newEmail = entrada.nextLine();
						
						sm.updateStudent(id,newName, newEmail);
						
						break;
					case 4:
						int id1;
						System.out.println("Digite o id do estudante que você deseja excluir:");
						id1 = entrada.nextInt();
						sm.deleteStudent(id1);
					case 5:
						sair = false;
						break;
					default:
						break;
				}	
			}while(sair);
			
			
		}
		
	}

}
