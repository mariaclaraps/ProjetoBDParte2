package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

	public static String DB_URL = "jdbc:mysql://localhost/school";
    private static String DB_USER = "root";
    private static String DB_PASSWORD = "root";  
    
    private static Connection conn;
    
    public static Connection obterConexao() {
    	if (conn == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }
}
